package Booking;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.WebDriver.Navigation;

public class Akomodasi {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "C:\\Program Files\\chromedriver_win32\\chromedriver.exe");
		
		//create a new instance of the chrome driver
		WebDriver wd = new ChromeDriver();
		
		//launch the tiket
		wd.get("https://booking.com");
		
		//Type xpath logo negara
		wd.findElement(By.xpath("//*[@id=\"b2indexPage\"]/header/nav[1]/div[2]/div[2]/button")).click();
		
		//Type xpath indonesia
		wd.findElement(By.xpath("//*[@id=\"language-selection\"]/div/div/div/div/div/div[1]/div/div[2]/div/ul/div[1]/ul/li[1]/a/div/div[2]")).click();
		
		wd.findElement(By.xpath("//*[@id=\"b2indexPage\"]/header/nav[2]/ul/li[1]/a/span[2]")).click();
		
		//Type xpath in the search text box
		wd.findElement(By.xpath("//*[@id=\"ss\"]")).sendKeys("Jakarta");
		
		//Type xpath check-in
		wd.findElement(By.xpath("//*[@id=\"frm\"]/div[1]/div[2]/div[1]/div[3]/div/div/div/div/span")).click();
		
		//Type xpath check-out
		wd.findElement(By.xpath("//*[@id=\"frm\"]/div[1]/div[2]/div[2]/div/div/div[3]/div[2]/table/tbody/tr[2]/td[3]/span/span")).click();
		
		//Type xpath search
		wd.findElement(By.xpath("//*[@id=\"frm\"]/div[1]/div[2]/div[2]/div/div/div[3]/div[2]/table/tbody/tr[3]/td[3]/span/span")).click();
		
		//Type xpath lihat ketersediaan
		wd.findElement(By.xpath("//*[@id=\"frm\"]/div[1]/div[4]/div[2]/button")).click();

		wd.findElement(By.xpath("//*[@id=\"search_results_table\"]/div/div/div/div/div[6]/div[6]/div[1]/div[2]/div/div[2]/div/div[2]/div/div[2]/div/a")).click();
		
		wd.findElement(By.xpath("//*[@id=\"hotel_main_content\"]/div/div[1]/div[4]/a")).click();
		
		//Print message to the screen
		System.out.println("Successfully opened the website Booking.com DemoQA");
		
		//Wait for 5 secs
		Thread.sleep(5000);
		
		//Close the driver
		wd.quit();
	}

}