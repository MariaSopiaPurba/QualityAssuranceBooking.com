package Booking;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.WebDriver.Navigation;

public class Attraction {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "C:\\Program Files\\chromedriver_win32\\chromedriver.exe");
		
		//create a new instance of the chrome driver
		WebDriver wd = new ChromeDriver();
		
		//launch the tiket
		wd.get("https://booking.com");

		//Type xpath logo negara
		wd.findElement(By.xpath("//*[@id=\"b2indexPage\"]/header/nav[1]/div[2]/div[2]/button")).click();
				
		//Type xpath indonesia
		wd.findElement(By.xpath("//*[@id=\"language-selection\"]/div/div/div/div/div/div[1]/div/div[2]/div/ul/div[1]/ul/li[1]/a/div/div[2]")).click();
				
		wd.findElement(By.xpath("//*[@id=\"b2indexPage\"]/header/nav[2]/ul/li[5]/a")).click();
				
		//Type xpath Penerbangan dan Hotel
		wd.findElement(By.xpath("/html/body/div[2]/div/div/div/div[1]/div/div/div/div[3]/div/div/form/div/input")).sendKeys("Taman mini indonesia");
		
		//Type xpath 
		wd.findElement(By.xpath("/html/body/div[2]/div/div/div/div[2]/div/div[1]/div[3]/div[1]/div/div/div[1]/div/div/a/div[2]/div[2]/span")).click();
		
		//Print message to the screen
		System.out.println("Successfully opened the website Booking.com DemoQA");
		
		//Wait for 5 secs
		Thread.sleep(5000);
		
		//Close the driver
		wd.quit();
	}
}