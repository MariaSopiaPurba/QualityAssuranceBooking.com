package Booking;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.WebDriver.Navigation;

public class Login {
	public static void main(String[] args) throws InterruptedException {	
		System.setProperty("webdriver.chrome.driver", "C:\\Program Files\\chromedriver_win32\\chromedriver.exe");
		//create a new instance of the chrome driver
		WebDriver wd = new ChromeDriver();
		
		//launch the tiket
		wd.get("https://booking.com");
		
		//Type sign in
		wd.findElement(By.xpath("//*[@id=\"b2indexPage\"]/header/nav[1]/div[2]/div[6]/a")).click();
		
		//daftar akun
		wd.findElement(By.xpath("//*[@id=\"username\"]")).sendKeys("kelompok3pkpl@gmail.com");
		
		//continue email
		wd.findElement(By.xpath("//*[@id=\"root\"]/div/div/div/div[2]/div[1]/div/div/div/div/div/div/form/div[3]/button")).click();
		
		//back to sign-in
		wd.findElement(By.xpath("//*[@id=\"root\"]/div/div/div/div[2]/div[1]/div/div/div/div/div/div/div/a/button")).click();
		
		System.out.println("Successfully opened the website Booking.com DemoQA");
		
		//Wait for 5 secs
		Thread.sleep(5000);
		
		//Close the driver
		wd.quit();
	}

}