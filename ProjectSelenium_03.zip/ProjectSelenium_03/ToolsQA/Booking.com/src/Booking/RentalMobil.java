package Booking;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.WebDriver.Navigation;

public class RentalMobil {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "C:\\Program Files\\chromedriver_win32\\chromedriver.exe");
		
		//create a new instance of the chrome driver
		WebDriver wd = new ChromeDriver();
		
		//launch the tiket
		wd.get("https://booking.com");
		
		//Type xpath klik car rentals
		wd.findElement(By.xpath("//*[@id=\"b2indexPage\"]/header/nav[2]/ul/li[4]/a/span[2]")).click();
		
		//Type xpathin the search alamat text box
		wd.findElement(By.xpath("//*[@id=\"ss_origin\"]")).sendKeys("Jakarta CBD, Jakarta Province, Indonesia");
		
		//Type xpath tanggal rental 
		wd.findElement(By.xpath("//*[@id=\"frm\"]/div[2]/div[3]/div/div[2]/div/div/div/div[1]/div/button")).click();
		wd.findElement(By.xpath("//*[@id=\"frm\"]/div[2]/div[3]/div/div[2]/div/div/div/div[2]/div[2]/div[3]/div/div/div[1]/table/tbody/tr[3]/td[4]")).click();
		
		//Type xpath tanggal pengembalian 
		wd.findElement(By.xpath("//*[@id=\"frm\"]/div[2]/div[3]/div/div[3]/div/div[2]/div/div[1]/div/button")).click();
		wd.findElement(By.xpath("//*[@id=\"frm\"]/div[2]/div[3]/div/div[3]/div/div[2]/div/div[2]/div[2]/div[3]/div/div/div[2]/table/tbody/tr[2]/td[3]/span")).click();
		
		//Type xpath check-out
		wd.findElement(By.xpath("//*[@id=\"frm\"]/div[2]/div[4]/div[2]/button")).click();
		
		//Print message to the screen
		System.out.println("Successfully opened the website Booking.com DemoQA");
		
		//Wait for 5 secs
		Thread.sleep(5000);
		
		//Close the driver
		wd.quit();
	}

}